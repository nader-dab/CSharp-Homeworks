﻿namespace _03.SimpleFactory
{
    class FigureZ : Figure
    {
        public FigureZ()
            : base(new int[,] { { 1, 1, 0 }, { 0, 1, 1 } })
        {
        }
    }
}
