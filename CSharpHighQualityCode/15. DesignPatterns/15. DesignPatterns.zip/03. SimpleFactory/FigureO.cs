﻿namespace _03.SimpleFactory
{
    class FigureO : Figure
    {
        public FigureO()
            :base(new int[,] { { 1, 1 }, { 1, 1 } })
        {
        }
    }
}
